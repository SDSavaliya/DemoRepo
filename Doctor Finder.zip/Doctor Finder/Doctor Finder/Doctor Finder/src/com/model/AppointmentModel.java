package com.model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import com.DBconnection.DBconnection;
import com.bin.Appointmentbean;
import com.bin.Feedbackbean;

public class AppointmentModel 
{

	public void addappointment(Appointmentbean s) 
	{
		try 
		{
			DBconnection db = new DBconnection();
			Connection conn = db.getconnection();
			String sql = "insert into appointment(DrName,DrSpeciality,AppointmentDate,AppointmentTime) values(?,?,?,?)";
			PreparedStatement pst = conn.prepareStatement(sql);
			pst.setString(1, s.getDrName());
			pst.setString(2, s.getDrSpeciality());
			pst.setString(3, s.getAppointmentDate());
			pst.setString(4, s.getAppointmentTime());
			int i = pst.executeUpdate();
			if(i>0)
				System.out.println("success");
			else
				System.out.println("fail");
		} 
		catch (Exception e) 
		{
			e.printStackTrace();
		}
	}	
	public Appointmentbean cancelappointment()
	{
		Appointmentbean s =null;
		try 
		{
			DBconnection db = new DBconnection();
			Connection conn = db.getconnection();
			String sql = "select * from appointment";
			PreparedStatement pst = conn.prepareStatement(sql);
			ResultSet rs = pst.executeQuery();
			
			while(rs.next())
			{
				s=new Appointmentbean();
				s.setId(Integer.parseInt(rs.getString("id")));
				s.setDrName(rs.getString("drname"));
				s.setDrSpeciality(rs.getString("DrSpeciality"));
				s.setAppointmentDate(rs.getString("AppointmentDate"));
				s.setAppointmentTime(rs.getString("AppointmentTime"));
			}
		} 
		catch (Exception e) 
		{
			e.printStackTrace();
		}
		return s;
	}
	public int deleteappointment(Appointmentbean s) 
	{
		int i = 0;
		try 
		{
			DBconnection db = new DBconnection();
			Connection conn = db.getconnection();
			String sql = "delete from appointment where id=?";
			PreparedStatement pst = conn.prepareStatement(sql);
			pst.setInt(1, s.getId());
			i = pst.executeUpdate();
			
		} 
		catch (Exception e) 
		{
			e.printStackTrace();
		}
		return i;
	}
	
	public ArrayList<Appointmentbean> showappointment()
	{
		ArrayList<Appointmentbean> app = new ArrayList<Appointmentbean>();
		
		try
		{
			DBconnection db = new DBconnection();
			Connection cnn = db.getconnection();
			
			String sql = "select * from appointment";
			
			PreparedStatement pst = cnn.prepareStatement(sql);
			
			ResultSet rs = pst.executeQuery();
			
			while(rs.next())
			{
				Appointmentbean app1 = new Appointmentbean();
				app1.setId(rs.getInt("id"));
				app1.setDrName(rs.getString("DrName"));
				app1.setDrSpeciality(rs.getString("DrSpeciality"));
				app1.setAppointmentDate(rs.getString("AppointmentDate"));
				app1.setAppointmentTime(rs.getString("AppointmentTime"));
				app.add(app1);
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
		return app;
	}
	
	public void admindelappt(int id) 
	{
		try
		{
			DBconnection db = new DBconnection();
			Connection cnn = db.getconnection();
			
			String sql = "delete from appointment where id=?";
			
			PreparedStatement pst = cnn.prepareStatement(sql);
			pst.setInt(1, id);
			int i = pst.executeUpdate();
			
			if(i>0)
			{
				System.out.println("Admin Side Appt Deleted");
			}
			else
			{
				System.out.println("Admin Side Appt Not Deleted");
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}

}
